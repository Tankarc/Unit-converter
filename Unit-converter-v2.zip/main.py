
mm_to_cm = 0.1
cm_to_m = 0.01
m_to_km = 0.001

def convert_units():
    
    current_unit = input("What unit do you want to convert from? (mm, cm, m, km): ").lower()
    print("Your unit is:", current_unit)

    new_unit = input("What unit do you want your number to be converted to? (mm, cm, m, km): ").lower()
    print("Your unit to convert your number to is:", new_unit)

    value = float(input("What is your value? "))

    
    if current_unit == "mm":
        if new_unit == "cm":
            converted_value = value * mm_to_cm
        elif new_unit == "m":
            converted_value = value * mm_to_cm * cm_to_m
        elif new_unit == "km":
            converted_value = value * mm_to_cm * cm_to_m * m_to_km
        else:
            print("Invalid unit, please try again.")
            return None
    elif current_unit == "cm":
        if new_unit == "mm":
            converted_value = value / mm_to_cm
        elif new_unit == "m":
            converted_value = value * cm_to_m
        elif new_unit == "km":
            converted_value = value * cm_to_m * m_to_km
        else:
            print("Invalid unit, please try again.")
            return None
    elif current_unit == "m":
        if new_unit == "mm":
            converted_value = value / (mm_to_cm * cm_to_m)
        elif new_unit == "cm":
            converted_value = value / cm_to_m
        elif new_unit == "km":
            converted_value = value * m_to_km
        else:
            print("Invalid unit, please try again.")
            return None
    elif current_unit == "km":
        if new_unit == "mm":
            converted_value = value / m_to_km / cm_to_m / mm_to_cm
        elif new_unit == "cm":
            converted_value = value / m_to_km / cm_to_m
        elif new_unit == "m":
            converted_value = value / m_to_km
        else:
            print("Invalid unit, please try again.")
            return None

    return converted_value


result = convert_units()
if result is not None:
      print("The converted value is:", result)
else:
      print("Conversion failed due to invalid input.")